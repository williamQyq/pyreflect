from .data_processor import SLDChiDataProcessor,NRSLDDataProcessor

__all__ = [
    "SLDChiDataProcessor",
    "NRSLDDataProcessor"
]

